const botao_Cadastrar = document.getElementById('cadastrarCliente');
botao_Cadastrar.addEventListener('click', abrir_Modal);

function abrir_Modal(){
    document.getElementById('modal').classList.add('active');
}


const botao_Fechar = document.getElementById('fechar');
botao_Fechar.addEventListener('click', fechar_Modal);

function fechar_Modal(){
    document.getElementById('modal').classList.remove('active');
}


const botao_Cancelar = document.getElementById('cancelar');
botao_Cancelar.addEventListener('click', limpar_Inputs);

function limpar_Inputs(){
    document.getElementById('modal-form').reset();
}

const botao_Salvar = document.getElementById('salvar');
botao_Salvar.addEventListener('click', salvar_Registros);

async function salvar_Registros(evento) {
    evento.preventDefault();
    const nome = document.getElementById('nome').value.trim();
    const email = document.getElementById('email').value.trim();
    const celular = parseInt(document.getElementById('celular').value.trim());
    const cidade =  document.getElementById('cidade').value.trim();

    if (!nome || !email || !celular || !cidade) {
        alert ("Preencha todos os campos!!!")
        return;
    }

    try {
    const resposta = await fetch('/salvar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nome, email, celular, cidade})
    });

    const data = await resposta.json();

    if (resposta.ok) {
      alert(data.message);
      limpar_Inputs();
      
    } else {
      alert('Erro ao salvar: ' + data.message);
    }
  } catch (error) {
    alert('Erro na comunicação com o servidor.');
    console.error(error);
  }

  fechar_Modal();
  location.reload();
 
}
    

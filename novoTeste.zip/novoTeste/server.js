const express = require('express');
const mongoose = require('mongoose');

const Escritorio = require('./models/Escritorio');
const app = express(); 

app.use(express.json());
app.use(express.static('public'));

// CONECTA O SERVIDOR NODE.JS AO BANCO DE DADOS MONGODB
// SE ELE NÃO EXISTIR AINDA, O MONGODB CRIA AUTOMATICAMENTE QUANDO O USUÁRIO SALVAR O PRIMEIRO DADO.
mongoose.connect('mongodb://localhost:27017/Almoxarifado')
  .then(() => console.log('MongoDB conectado!'))
  .catch(err => console.error('Erro na conexão:', err));


  

// INICIA O SERVIDOR EXPRESS DENTRO DO NODE.JS
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});




// FUNÇÃO QUE GERA UM ID  CRESCENTE PARA CADA NOVO REGISTRO
async function gerarCustomId() {
  const ultima = await Escritorio.findOne().sort({ customId: -1 });
  return ultima ? ultima.customId + 1 : 1;
}


// ROTA PARA SALVAR OS DADOS
app.post('/salvar', async (req, res) => {
  try {
    const {nome, email, celular, cidade } = req.body;

    // AQUI VERIFICA SE JÁ EXISTE UM USUÁRIO ADMINISTRADOR COM O MESMO NOME
    //CONSIDERAMOS QUE nome_INPUT1 SEJA O INPUT COM O NOME DE nome
    const existente = await Escritorio.findOne({ nome });
    if (existente) {
      return res.status(409).json({ message: 'Este nome de usuário já está em uso.' });
    }

    
    const customId = await gerarCustomId(); // -> AQUI ELE GERA UM IP FIXO PARA CADA REGISTRO

    const escritorio = new Escritorio({ customId, nome, celular, email, cidade});
    await escritorio.save();

    console.log('Dados salvos:', escritorio);
    res.status(201).json({ message: 'Dados salvos com sucesso!' });
  } catch (error) {
    console.error('Erro ao salvar dados:', error);
    res.status(500).json({ message: 'Erro ao salvar dados' });
  }
});

// ROTA PARA LISTAR OS REGISTROS
app.get('/registros', async (req, res) => {
  try {
    const registros = await Escritorio.find();
    res.json(registros);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao buscar registros' });
  }
});

// ROTA PARA ATUALIZAR REGISTRO
app.put('/atualizar/:id', async (req, res) => {
  const id = parseInt(req.params.id);
  const { nome, celular, email, cidade} = req.body;

  try {
    await Escritorio.updateOne(
      { customId: id },
      { $set: { nome, celular, email, cidade} }
    );
    res.sendStatus(200);
  } catch (err) {
    console.error('Erro ao atualizar:', err);
    res.status(500).send('Erro ao atualizar registro');
  }
});


// ROTA PARA EXCLUIR REGISTRO
app.delete('/excluir/:customId', async (req, res) => {
  await Escritorio.findOneAndDelete({ customId: req.params.customId });
  res.json({ message: 'Registro excluído!' });
});